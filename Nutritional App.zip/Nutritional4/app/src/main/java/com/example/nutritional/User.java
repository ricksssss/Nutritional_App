package com.example.nutritional;

public class User {
    public String fullName;
    public String regWeight;
    public String email;

    public User() {

    }

    public User(String fullName, String regWeight, String email) {
        this.fullName = fullName;
        this.regWeight = regWeight;
        this.email = email;
    }

}
