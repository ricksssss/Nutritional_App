package com.example.nutritional;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class activity_spinach extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spinach);
    }
}